# Captain Planet Game

## Instructions

* Create a new superpower for Captain Planet using jQuery.

  * Look at the [jQuery API documents](https://api.jquery.com/) if you get stuck 
  
* Examples:
  * Click to… Stretch Captain Planet!
  * Click to… Trigger a maniacal laugh!
  * Click to… Create clones of Captain Planet!
  * Click to… Create fire or water (hint: images)!

* Slack out a screenshot of the working example.

---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
